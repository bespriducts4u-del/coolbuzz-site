import React from "react";

export default function App() {
  const products = [
    { id: 1, name: "Vintage Sneakers", price: "$120" },
    { id: 2, name: "Streetwear Hoodie", price: "$75" },
    { id: 3, name: "Designer Backpack", price: "$210" },
    { id: 4, name: "Limited Edition Cap", price: "$45" },
  ];

  return (
    <div style={{color:"white", background:"black", minHeight:"100vh"}}>
      <header style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"16px",borderBottom:"1px solid #222"}}>
        <div style={{display:"flex",alignItems:"center",gap:"10px"}}>
          <img src="/logo.png" style={{height:"40px"}} />
          <h1 style={{color:"#3b82f6"}}>CoolBuzz</h1>
        </div>
        <button style={{padding:"8px 14px",background:"#3b82f6",border:"none",borderRadius:"8px",color:"white"}}>
          Cart
        </button>
      </header>

      <section style={{textAlign:"center",padding:"60px 20px"}}>
        <h2 style={{fontSize:"42px",color:"#3b82f6"}}>Buy & Resell Trending Items</h2>
        <p style={{color:"#aaa"}}>Your marketplace for sneakers, streetwear, and exclusive finds.</p>
      </section>

      <main style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))",gap:"20px",padding:"20px"}}>
        {products.map(p => (
          <div key={p.id} style={{background:"#111",borderRadius:"12px",padding:"16px"}}>
            <div style={{height:"140px",background:"#222",borderRadius:"8px"}}></div>
            <h3>{p.name}</h3>
            <p style={{color:"#3b82f6"}}>{p.price}</p>
            <button style={{width:"100%",marginTop:"10px",padding:"10px",background:"#3b82f6",border:"none",borderRadius:"8px",color:"white"}}>
              Buy Now
            </button>
          </div>
        ))}
      </main>

      <footer style={{textAlign:"center",padding:"20px",color:"#777"}}>
        © CoolBuzz Marketplace
      </footer>
    </div>
  );
}
